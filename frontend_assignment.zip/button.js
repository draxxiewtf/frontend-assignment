import React from "react";
import "./button.css";

const Button = () => {
  return (
    <div className="button-container">
      <button className="button">Done</button>
      <button className="button">Done</button>
      <button className="button">Done</button>
    </div>
  );
};

export default Button;
